
package com.user.test.config;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import com.user.core.CollateralSsi;
import com.user.core.CollateralSsiDAO;
import com.user.core.test.AppTestConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
@TransactionConfiguration(defaultRollback = true)
public class UserDAOTest extends BaseDBUnitSetup {

	@Autowired
	private CollateralSsiDAO collateralSsiDAO;

	@Test
	public void testFind() {
		CollateralSsi user = collateralSsiDAO.find(1);
		assertNotNull(user);

		user = collateralSsiDAO.find(2);
		assertNotNull(user);

		user = collateralSsiDAO.find(10);
		assertNull(user);

		user = collateralSsiDAO.find(40);
		assertNull(user);

		user = collateralSsiDAO.find(50);
		assertNull(user);
	}

	// @Test
	// @Transactional
	// public void testInsert() {
	// User user = new User();
	// user.setId(3);
	// user.setName("Michael Dell");
	// user.setPhone(44657688);
	// user.setSex("M");
	// collateralSsiDAO.create(user);
	//
	// User actualUser = collateralSsiDAO.find(3);
	// assertEquals(actualUser, user);
	// }
	//
	// @Test
	// @Transactional
	// public void testUpdate() {
	// User user = collateralSsiDAO.find(1);
	// user.setPhone(12345678);
	// collateralSsiDAO.update(user);
	//
	// user = collateralSsiDAO.find(1);
	// assertEquals(12345678, user.getPhone());
	// }
	//
	// @Test
	// @Transactional
	// public void testRemove() {
	// User user = collateralSsiDAO.find(1);
	// collateralSsiDAO.delete(user);
	//
	// user = collateralSsiDAO.find(1);
	// assertNull(user);
	// }
	//
}
