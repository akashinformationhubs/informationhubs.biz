
package com.user.service.test;

import static org.junit.Assert.assertEquals;

import java.sql.Date;

import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.user.core.CollateralSsi;
import com.user.core.CollateralSsiDAO;

public class CollateralSsiDAOTest {

	private static CollateralSsiDAO collateralSsiDAO;

	private static CollateralSsi mocked = newCollateralSsi();

	private static CollateralSsi newCollateralSsi() {
		CollateralSsi collateralSsi = new CollateralSsi();
		collateralSsi.setBrokerId("12");
		collateralSsi.setProductLine("12");
		collateralSsi.setSettlementLocation("12");
		collateralSsi.setHouseAccount("12");
		collateralSsi.setBrokerAccountNumber("12");
		collateralSsi.setExecutingBroker("12");
		collateralSsi.setClearingBroker("12");
		collateralSsi.setExecutingBic("12");
		collateralSsi.setClearingBic("12");
		collateralSsi.setFedMnemonic("12");
		collateralSsi.setSsiStatus("12");
		collateralSsi.setCreateBy("12");
		collateralSsi.setCreatedDateTime(new Date(System.currentTimeMillis()));
		collateralSsi.setLastModifiedBy("12");
		collateralSsi.setLastModDateTime(new Date(System.currentTimeMillis()));
		collateralSsi.setApprovedBy("12");
		collateralSsi.setApprovedDateTime(new Date(System.currentTimeMillis()));
		collateralSsi.setBrokerSubAccount("12");
		collateralSsi.setDepositoryPartCode("12");
		collateralSsi.setSeqNum(12);
		collateralSsi.setActivity(1);
		return collateralSsi;
	}

	@BeforeClass
	public static void beforeClass() {
		collateralSsiDAO = Mockito.mock(CollateralSsiDAO.class);

		Mockito.when(collateralSsiDAO.find(Mockito.anyInt())).thenReturn(mocked);
		Mockito.doThrow(new RuntimeException("error on user object!")).when(collateralSsiDAO).delete((CollateralSsi) Mockito.any());
		Mockito.doNothing().when(collateralSsiDAO).create((CollateralSsi) Mockito.any());

		Mockito.doAnswer(new Answer<Object>() {

			public Object answer(InvocationOnMock invocation) {
				Object[] args = invocation.getArguments();
				CollateralSsi user = (CollateralSsi) args[0];
				user.setBrokerId("34");
				return user;
			}
		}).when(collateralSsiDAO).update((CollateralSsi) Mockito.any());
	}

	@Test
	public void testFind() {
		CollateralSsi collateralSsi = collateralSsiDAO.find(10);
		Mockito.verify(collateralSsiDAO).find(10);
		assertEquals(collateralSsi.getBrokerId(), "12");
	}

	@Test
	public void testInsert() {
		collateralSsiDAO.create(mocked);
		Mockito.verify(collateralSsiDAO).create(mocked);
	}

	@Test
	public void testUpdate() {
		CollateralSsi collateralSsi = collateralSsiDAO.find(123);
		collateralSsi.setActivity(0);
		collateralSsiDAO.update(collateralSsi);
		Mockito.verify(collateralSsiDAO).update(collateralSsi);
		assertEquals(collateralSsi.getActivity(), 0);
	}

	@Test(expected = RuntimeException.class)
	public void testRemove() {
		CollateralSsi collateralSsi = collateralSsiDAO.find(123);
		collateralSsiDAO.delete(collateralSsi);
	}

}
