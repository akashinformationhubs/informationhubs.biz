-- INSERT INTO COLLATERAL_SSI(BROKER_ID, PRODUCT_LINE) VALUES('123', '123');

INSERT INTO COLLATERAL_SSI VALUES(123, 'Ne', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Te', 'Test', null, 'Test', null, 'Test', null, 'Test', 'Test', 123, '1');
