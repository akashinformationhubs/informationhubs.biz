
package com.user.core;

import java.io.Serializable;
import java.sql.Date;

public class CollateralSsi implements Serializable {

	private static final long serialVersionUID = 1L;

	private String brokerId;

	private String productLine;

	private String settlementLocation;

	private String houseAccount;

	private String brokerAccountNumber;

	private String executingBroker;

	private String clearingBroker;

	private String executingBic;

	private String clearingBic;

	private String fedMnemonic;

	private String ssiStatus;

	private String createBy;

	private Date createdDateTime;

	private String lastModifiedBy;

	private Date lastModDateTime;

	private String approvedBy;

	private Date approvedDateTime;

	private String brokerSubAccount;

	private String depositoryPartCode;

	private int seqNum;

	private int activity;

	public String getBrokerId() {
		return brokerId;
	}

	public void setBrokerId(String brokerId) {
		this.brokerId = brokerId;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getSettlementLocation() {
		return settlementLocation;
	}

	public void setSettlementLocation(String settlementLocation) {
		this.settlementLocation = settlementLocation;
	}

	public String getHouseAccount() {
		return houseAccount;
	}

	public void setHouseAccount(String houseAccount) {
		this.houseAccount = houseAccount;
	}

	public String getBrokerAccountNumber() {
		return brokerAccountNumber;
	}

	public void setBrokerAccountNumber(String brokerAccountNumber) {
		this.brokerAccountNumber = brokerAccountNumber;
	}

	public String getExecutingBroker() {
		return executingBroker;
	}

	public void setExecutingBroker(String executingBroker) {
		this.executingBroker = executingBroker;
	}

	public String getClearingBroker() {
		return clearingBroker;
	}

	public void setClearingBroker(String clearingBroker) {
		this.clearingBroker = clearingBroker;
	}

	public String getExecutingBic() {
		return executingBic;
	}

	public void setExecutingBic(String executingBic) {
		this.executingBic = executingBic;
	}

	public String getClearingBic() {
		return clearingBic;
	}

	public void setClearingBic(String clearingBic) {
		this.clearingBic = clearingBic;
	}

	public String getFedMnemonic() {
		return fedMnemonic;
	}

	public void setFedMnemonic(String fedMnemonic) {
		this.fedMnemonic = fedMnemonic;
	}

	public String getSsiStatus() {
		return ssiStatus;
	}

	public void setSsiStatus(String ssiStatus) {
		this.ssiStatus = ssiStatus;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModDateTime() {
		return lastModDateTime;
	}

	public void setLastModDateTime(Date lastModDateTime) {
		this.lastModDateTime = lastModDateTime;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDateTime() {
		return approvedDateTime;
	}

	public void setApprovedDateTime(Date approvedDateTime) {
		this.approvedDateTime = approvedDateTime;
	}

	public String getBrokerSubAccount() {
		return brokerSubAccount;
	}

	public void setBrokerSubAccount(String brokerSubAccount) {
		this.brokerSubAccount = brokerSubAccount;
	}

	public String getDepositoryPartCode() {
		return depositoryPartCode;
	}

	public void setDepositoryPartCode(String depositoryPartCode) {
		this.depositoryPartCode = depositoryPartCode;
	}

	public int getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(int seqNum) {
		this.seqNum = seqNum;
	}

	public int getActivity() {
		return activity;
	}

	public void setActivity(int activity) {
		this.activity = activity;
	}

}
