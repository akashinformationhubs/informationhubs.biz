
package com.user.core;

import java.sql.Date;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) throws SQLException {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);

		CollateralSsiDAO service = context.getBean(CollateralSsiDAO.class);

		CollateralSsi collateralSsi = service.find(123);
		System.out.println(collateralSsi);

		collateralSsi.setBrokerId("123");
		service.update(collateralSsi);

		service.delete(collateralSsi);
		service.create(newCollateralSsi());
	}

	private static CollateralSsi newCollateralSsi() throws SQLException {
		CollateralSsi collateralSsi = new CollateralSsi();
		collateralSsi.setBrokerId("12");
		collateralSsi.setProductLine("12");
		collateralSsi.setSettlementLocation("12");
		collateralSsi.setHouseAccount("12");
		collateralSsi.setBrokerAccountNumber("12");
		collateralSsi.setExecutingBroker("12");
		collateralSsi.setClearingBroker("12");
		collateralSsi.setExecutingBic("12");
		collateralSsi.setClearingBic("12");
		collateralSsi.setFedMnemonic("12");
		collateralSsi.setSsiStatus("12");
		collateralSsi.setCreateBy("12");
		collateralSsi.setCreatedDateTime(new Date(System.currentTimeMillis()));
		collateralSsi.setLastModifiedBy("12");
		collateralSsi.setLastModDateTime(new Date(System.currentTimeMillis()));
		collateralSsi.setApprovedBy("12");
		collateralSsi.setApprovedDateTime(new Date(System.currentTimeMillis()));
		collateralSsi.setBrokerSubAccount("12");
		collateralSsi.setDepositoryPartCode("12");
		collateralSsi.setSeqNum(12);
		collateralSsi.setActivity(1);
		return collateralSsi;
	}

}
