
package com.user.core;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class CollateralSsiDAO {

	@Autowired
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	private static final String SEARCH_QUERY = "SELECT * FROM COLLATERAL_SSI WHERE BROKER_ID = ?";

	private static final String INSERT_QUERY = "INSERT INTO COLLATERAL_SSI(BROKER_ID, PRODUCT_LINE, SETTLEMENT_LOCATION, HOUSE_ACCOUNT, BROKER_ACCOUNT_NUMBER, EXECUTING_BROKER, CLEARING_BROKER, EXECUTING_BIC, CLEARING_BIC, FED_MNEMONIC, SSI_STATUS, CREATE_BY, CREATED_DATETIME, LAST_MODIFIED_BY, LAST_MOD_DATETIME, APPROVED_BY, APPROVED_DATETIME, BROKER_SUBACCOUNT, DEPOSITORY_PART_CODE, SEQ_NUM, ACTIVITY) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String UPDATE_QUERY = "UPDATE COLLATERAL_SSI SET PRODUCT_LINE=? WHERE BROKER_ID = ?";

	private static final String DELETE_QUERY = "DELETE FROM COLLATERAL_SSI WHERE BROKER_ID = ?";

	public CollateralSsiDAO() {

	}

	private JdbcTemplate getJdbcTemplate() {
		if (jdbcTemplate == null)
			return new JdbcTemplate(dataSource);
		return jdbcTemplate;
	}

	public CollateralSsi find(int id) {
		return getJdbcTemplate().queryForObject(SEARCH_QUERY, new Object[] { id }, new CollateralSsiRowMapper());
	}

	public void create(CollateralSsi collateralSsi) {
		getJdbcTemplate().update(INSERT_QUERY, collateralSsi.getBrokerId(), collateralSsi.getProductLine(), collateralSsi.getSettlementLocation(), collateralSsi.getHouseAccount(), collateralSsi.getBrokerAccountNumber(), collateralSsi.getExecutingBroker(), collateralSsi.getClearingBic(), collateralSsi.getFedMnemonic(), collateralSsi.getSsiStatus(), collateralSsi.getCreateBy(), collateralSsi.getCreatedDateTime(), collateralSsi.getLastModifiedBy(), collateralSsi.getLastModDateTime(), collateralSsi.getApprovedBy(), collateralSsi.getApprovedDateTime(), collateralSsi.getBrokerSubAccount(), collateralSsi.getDepositoryPartCode(), collateralSsi.getSeqNum(), collateralSsi.getActivity());
	}

	public void update(CollateralSsi collateralSsi) {
		getJdbcTemplate().update(UPDATE_QUERY, collateralSsi.getProductLine(), collateralSsi.getBrokerId());
	}

	public void delete(CollateralSsi collateralSsi) {
		getJdbcTemplate().update(DELETE_QUERY, collateralSsi.getBrokerId());
	}

	public static class CollateralSsiRowMapper implements RowMapper<CollateralSsi> {

		public CollateralSsi mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			CollateralSsi collateralSsi = new CollateralSsi();
			collateralSsi.setBrokerId(resultSet.getString("BROKER_ID"));
			collateralSsi.setProductLine(resultSet.getString("PRODUCT_LINE"));
			collateralSsi.setSettlementLocation(resultSet.getString("SETTLEMENT_LOCATION"));
			collateralSsi.setHouseAccount(resultSet.getString("HOUSE_ACCOUNT"));
			collateralSsi.setBrokerAccountNumber(resultSet.getString("BROKER_ACCOUNT_NUMBER"));
			collateralSsi.setExecutingBroker(resultSet.getString("EXECUTING_BROKER"));
			collateralSsi.setClearingBroker(resultSet.getString("CLEARING_BROKER"));
			collateralSsi.setExecutingBic(resultSet.getString("EXECUTING_BIC"));
			collateralSsi.setClearingBic(resultSet.getString("CLEARING_BIC"));
			collateralSsi.setFedMnemonic(resultSet.getString("FED_MNEMONIC"));
			collateralSsi.setSsiStatus(resultSet.getString("SSI_STATUS"));
			collateralSsi.setCreateBy(resultSet.getString("CREATE_BY"));
			collateralSsi.setCreatedDateTime(resultSet.getDate("CREATED_DATETIME"));
			collateralSsi.setLastModifiedBy(resultSet.getString("LAST_MODIFIED_BY"));
			collateralSsi.setLastModDateTime(resultSet.getDate("LAST_MOD_DATETIME"));
			collateralSsi.setApprovedBy(resultSet.getString("APPROVED_BY"));
			collateralSsi.setApprovedDateTime(resultSet.getDate("APPROVED_DATETIME"));
			collateralSsi.setBrokerSubAccount(resultSet.getString("BROKER_SUBACCOUNT"));
			collateralSsi.setDepositoryPartCode(resultSet.getString("DEPOSITORY_PART_CODE"));
			collateralSsi.setSeqNum(resultSet.getInt("SEQ_NUM"));
			collateralSsi.setActivity(resultSet.getInt("ACTIVITY"));
			return collateralSsi;
		}
	}

}
