
package com.user.test.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.user.core.test.AppTestConfiguration;
import com.user.dao.UserDAO;
import com.user.model.User;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AppTestConfiguration.class)
@TransactionConfiguration(defaultRollback = true)
public class UserDAOTest extends BaseDBUnitSetup {

	@Autowired
	private UserDAO userDAO;

	@Test
	public void testFind() {
		User user = userDAO.find(1);
		assertNotNull(user);

		user = userDAO.find(2);
		assertNotNull(user);

		user = userDAO.find(10);
		assertNull(user);

		user = userDAO.find(40);
		assertNull(user);

		user = userDAO.find(50);
		assertNull(user);
	}

	@Test
	@Transactional
	public void testInsert() {
		User user = new User();
		user.setId(3);
		user.setName("Michael Dell");
		user.setPhone(44657688);
		user.setSex("M");
		userDAO.create(user);

		User actualUser = userDAO.find(3);
		assertEquals(actualUser, user);
	}

	@Test
	@Transactional
	public void testUpdate() {
		User user = userDAO.find(1);
		user.setPhone(12345678);
		userDAO.update(user);

		user = userDAO.find(1);
		assertEquals(12345678, user.getPhone());
	}

	@Test
	@Transactional
	public void testRemove() {
		User user = userDAO.find(1);
		userDAO.delete(user);

		user = userDAO.find(1);
		assertNull(user);
	}

}
